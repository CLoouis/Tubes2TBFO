Selamat datang pada program kalkulator sederhana kami!

Ada beberapa cara untuk menjalankan program:     
1. Anda bisa menjalankan file "kalkulator.exe" pada folder bin.
2. Anda mengkompile source code di folder src dengan cara mengetik "gcc -o main main.c pda.c stack.c stackchar.c mesintoken.c" di terminal dan menjalankan file main.

Terima kasih!

Dibuat oleh:
Kevin Nathaniel Wijaya - 13517072
Irfan Sofyana Putra - 13517078
Louis Cahyadi - 13517126