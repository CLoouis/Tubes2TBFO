#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main(){
    double x;
    double y;
    y = 1.0/3.0;
    x = pow((-1), (y));
    printf("%.6f", x);
}
